<?php $__env->startSection('content'); ?>
<main>
  <div class="container-fluid">


        <div id="app">
<dashboard/>

    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>
<script src="js/app.js"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lexsecuritygit\lexsecurity\resources\views/dashboard.blade.php ENDPATH**/ ?>