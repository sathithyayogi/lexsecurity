<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid">
        <h1 class="mt-4">List of Devices</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
            <li class="breadcrumb-item active">List of Devices</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <div class="row">
                    <div class="col-xl-6">
                        <i class="fas fa-table mr-1"></i>
                        Devices List
                    </div>
                    <div class="col-xl-6"><a href="/devices/create" class="btn btn-primary">Add Device</a></div>
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Device Name</th>
                                <th>Device ID</th>
                                <th>Mobile Number</th>
                                <th>Device Added Time</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>S.No</th>
                                <th>Device Name</th>
                                <th>Device ID</th>
                                <th>Mobile Number</th>
                                <th>Device Added Time</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php if(count($devices) > 0): ?>
                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($device->id); ?></td>
                                <td><?php echo e($device->deviceName); ?></td>
                                <td><?php echo e($device->deviceID); ?></td>
                                <td><?php echo e($device->mobileNumber); ?></td>
                                <td><?php echo e($device->created_at->diffForHumans()); ?></td>
                                <td><a href="/devices/<?php echo e($device->id); ?>/edit" class="btn btn-default">Edit</a></td>
                                <td>
                                    <form action="<?php echo e(action('deviceController@destroy', $device->id)); ?>" method="POST">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <?php echo e(csrf_field()); ?>

                                            <button class="form-control  btn btn-danger btn-block"  type="submit">DELETE</button>
                                        </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lexsecuritygit\lexsecurity\resources\views/device.blade.php ENDPATH**/ ?>