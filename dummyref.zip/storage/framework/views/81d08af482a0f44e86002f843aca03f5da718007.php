<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      <h1 class="mt-4">Diagnostics</h1>
      <ol class="breadcrumb mb-4">
          <li class="breadcrumb-item"><a href="/diagnostics">Dashboard</a></li>
          <li class="breadcrumb-item active"><?php echo e($device->id); ?></li>
      </ol>
    </div>
<diagnostic-show devid="<?php echo e($device->id); ?>" deviceid="<?php echo e($device->deviceID); ?>" devicename="<?php echo e($device->deviceName); ?>" connstatus="<?php echo e($device->connectionStatus); ?>" connstatustime="<?php echo e($device->connectionTime); ?>" noalarmraised="<?php echo e($device->alarmRaisedNo); ?>" noalarmactive="<?php echo e($device->alarmActiveNo); ?>" timeactivealarmone="<?php echo e($device->alarmOneTime); ?>" timeactivealarmtwo="<?php echo e($device->alarmOneTime); ?>" alarmonetottime="<?php echo e($device->alarmonetotTime); ?>" alarmtwotottime="<?php echo e($device->alarmtwototTime); ?>" alarmonerunstatus = "<?php echo e($device->alarmOneRunStatus); ?>" alarmtworunstatus = "<?php echo e($device->alarmTwoRunStatus); ?>" initialized="<?php echo e($device->initialized); ?>" movementstatus="<?php echo e($device->movementStatus); ?>"></diagnostic-show>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lexsecuritygit\lexsecurity\resources\views/show.blade.php ENDPATH**/ ?>