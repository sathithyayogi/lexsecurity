<?php $__env->startSection('content'); ?>
    

<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
      <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
          <div class="nav">
            <div class="sb-sidenav-menu-heading">Core</div>
            <a class="nav-link" href="index.html">
              <div class="sb-nav-link-icon">
                <i class="fas fa-tachometer-alt"></i>
              </div>
              Dashboard
            </a>
            <a class="nav-link" href="diagnostics.html">
              <div class="sb-nav-link-icon">
                <i class="fas fa-tachometer-alt"></i>
              </div>
              Diagnostics
            </a>
  
        
            
          
          </div>
        </div>
        <div class="sb-sidenav-footer">
          <div class="small">Logged in as:</div>
          LexLabs
        </div>
      </nav>
    </div>

    <div id="layoutSidenav_content">
      <main>
        <div class="container-fluid">
          <h1 class="mt-4">Diagnostics</h1>
          <ol class="breadcrumb mb-4">
              <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
              <li class="breadcrumb-item active">Diagnostics</li>
          </ol>
       
          <div class="row">
            <div class="col-xl-6">
              <div class="card mb-4">
                <div class="card-header">
                    <div class="row">
                    <div class="col-xl-6"> <i class="fas fa-tachometer-alt mr-1"></i>
                      DeviceOne</div>
                      <div class="col-xl-6"> 
                          <!-- <span class="rounded-circle"><i class="fas fa-circle mr-1"></i></span> -->
                       
                      </div>
                  </div>
                  
                </div>
                <div class="card-body">
                  <h1>Diagnostics</h1>
                
                  <div class="row">
                    <div class="col-xl-6">
                      <span class="badge badge-success">CONNECTED</span>
                      <!-- <span class="badge badge-danger">NOT CONNECTED</span> -->
                    </div>

                    <div class="col-xl-6">
                        <div class="row">
                      <p class="font-weight-bold">05:45:05</p>
                      <a  data-toggle="tooltip" data-placement="right" title="Elopsed Time">
                          <i class="fas fa-info-circle"></i>  
                        </a>
                      </div>
                    </div>
                  </div>

            

                  <div class="row">
                    <div class="col-xl-6 font-weight-bold">No. Of Alarm Raised</div>
                    <div class="col-xl-6 font-weight-bold">No. Of Active Alarm</div>
                    <div class="col-xl-6">54</div>
                    <div class="col-xl-6">1</div>
                  </div>

                  <div class="row">
                      <div class="col-xl-6"> <strong> Alarm 1 Active Time</strong></div>
                      <div class="col-xl-6"> <strong> Alarm 2 Active Time</strong></div>
                      <div class="col-xl-6">05:45:10</div>
                      <div class="col-xl-6">05:45:10</div>
                    </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid">
          <div
            class="d-flex align-items-center justify-content-between small"
          >
            <div class="text-muted">Copyright &copy; Your Website 2020</div>
            <div>
              <a href="#">Privacy Policy</a>
              &middot;
              <a href="#">Terms &amp; Conditions</a>
            </div>
          </div>
        </div>
      </footer>

    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lexlabs\lexsecurity\resources\views/welcome.blade.php ENDPATH**/ ?>