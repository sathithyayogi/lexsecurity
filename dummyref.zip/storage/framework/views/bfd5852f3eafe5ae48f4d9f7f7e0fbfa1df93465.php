<?php $__env->startSection('content'); ?>
<main>
  <div class="container-fluid">
 


    <div class="row">


      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xl-3">
        <div class="card xl-3">
          <div class="card-header">
            <div class="row">
              <div class="col-xl-12">
                DeviceOne
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="mainindicator"><p>red</p></div>
            <div class="row">
              <div class="col-xl-6">
                <span class="badge badge-success">CONNECTED</span>
                
              </div>
            </div>
          </div>

        </div>
      </div>


    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lexlabs\lexsecurity\resources\views/dashboard.blade.php ENDPATH**/ ?>