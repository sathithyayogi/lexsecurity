@extends('layouts.app')

@section('content')
<main>
  <div class="container-fluid">


        <div id="app">
<dashboard/>

    </div>
  </div>
</main>

@endsection
<script src="js/app.js"></script>
